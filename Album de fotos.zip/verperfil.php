<?php

require ('conexion.php');
    
if (empty($_SESSION['usuario'])){
    header ('location:login.php');
 };
   
?>

<html>
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
   <!-- Bootstrap Validator -->
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet"></link>

	<link href="//oss.maxcdn.com/jquery.bootstrapvalidator/0.5.2/css/bootstrapValidator.min.css" rel="stylesheet"></link>
	
<?php
include ('conexion.php');
  $sql= "select * from usuario where NomUsuario='".$_SESSION['usuario']."'";
    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) > 0) {
        
    // output data of each row
         while($row = mysqli_fetch_assoc($result)) {
             // se crea la variable de sesión usuario 
        $_SESSION['usuario']=$row['NomUsuario'];
        echo "Nombre: " . $row["NomUsuario"]. "<br>";
        echo "Email: " . $row['Email']. "<br>";
        
        if ( $row['Sexo']== 1) {
            echo "Sexo: Mujer <br>";
        }
        else {
            echo "Sexo: Hombre <br>";
        }
        $fecha_original = $row['FNacimiento'];
        $fecha = DateTime::createFromFormat('Y-m-d', $fecha_original);
        $fecha_formateada = $fecha->format('d/m/Y');
        echo "Fecha nacimiento: " .$fecha_formateada. "<br>";
        echo "Ciudad: " . $row['Ciudad']. "<br>";
        
        // tenemos que hacer una consulta a la tabla paises para mostrar el nombre
         $sql = "select * from pais where IdPais=".$row['Pais'];
        $result = mysqli_query($con, $sql);
        while($row1 = mysqli_fetch_assoc($result)) {
            echo "Pais: " .$row1['NomPais']."<br>";
        }
        $fecharegistro = $row['FRegistro'];
        $fecha2 = DateTime::createFromFormat('Y-m-d H:i:s', $fecharegistro);
        $fecha_formateada2 = $fecha2->format('d/m/Y H:i:s'); // formato con hora, minutos y segundos
        echo "Fecha de Registro: " .$fecha_formateada2. "<br>";
        echo "Foto: <img src='".$row['Foto']."'/>";"<br>";
    }
}
    mysqli_close($con);

?>
    <br>
    <br>
    <a class="btn btn-success" href="login.php">Volver al login</a>
   <a class="btn btn-success" href="index.php">Volver al menu de admin</a>

<!-- Enlaces a los servidores de BOotstrap Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" integrity="sha384-a5N7Y/aK3qNeh15eJKGWxsqtnX/wWdSZSKp+81YjTmS15nvnvxKHuzaWwXHDli+4" crossorigin="anonymous"></script>
</head>
</html>