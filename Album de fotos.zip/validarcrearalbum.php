<?php 
    if (empty($_SESSION['usuario'])){
        header ('location:login.php');
     };
require ('conexion.php');
    $sql="select IdUsuario from Usuario where NomUsuario='".$_SESSION['usuario']."';";

    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            // echo "El usuario actual es " . $_SESSION['usuario'] . " y su ID es "  . $row['IdUsuario']. "<br>" . "<br>";

            $idusuario = $row['IdUsuario'];

            if (isset($_REQUEST['Registrar'])) { 
              // banderas a valor 0 indican errores, a valor 1 indican correcto

          /* formato de la petición de inserción mediante orden sql */
           $query="select * from usuario";


              $sql="insert into album values ('','".$_REQUEST['titulo']."','".$_REQUEST['descripcion']."','".$_REQUEST['fecha']."','".$idusuario."');";

              if (mysqli_query($con, $sql)) {
             echo "<font color=green>Álbum creado correctamente</font>";
         } else {
             echo "<font color=red>Error: " . $sql . "<br>" . mysqli_error($con) . "</font>";
         }

         mysqli_close($con);
             }
        }
    };

    ?>