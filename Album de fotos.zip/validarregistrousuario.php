<?php
require("conexion.php");
$banderanombre = 1;
$sql = "select NomUsuario from usuario where NomUsuario='" . $_POST['nombre'] . "'";
$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "Aviso. El usuario existe";
    $banderanombre = 0;
}

if ($banderanombre == 1) {
 
    $nombre = $_POST["nombre"];
    $clave = $_POST["clave"];
    $email = $_POST["email"];
    $sexo = $_POST["sexo"];
    $fechanac = $_POST["fechanac"];
    $ciudad = $_POST["ciudad"];
    $pais = $_POST["pais"];

    // insertar las fotos
    $fileName = $_FILES["foto"]["name"];
    $fileTmpLoc = $_FILES["foto"]["tmp_name"];
    // Path and file name01
    $dir_subida = "./usuarios/".$nombre."/perfil";
    if (!is_dir($dir_subida)) {
        mkdir($dir_subida, 0777, true);
    }
    $fichero_subido = "./usuarios/".$nombre."/perfil/$fileName";
    // Run the move_uploaded_file() function here
    $moveResult = move_uploaded_file($fileTmpLoc, $fichero_subido);

    $sql = "insert into usuario(IdUsuario, NomUsuario, Clave, Email, Sexo, FNacimiento, Ciudad, Pais, Foto, FRegistro) 
    values('', '$nombre', $clave, '$email', '$sexo' ,'$fechanac', '$ciudad', '$pais', '$fichero_subido', current_time)";

    if (mysqli_query($con, $sql)) {
        echo "Nuevo usuario creado satisfactoriamente";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($con);
    }
    mysqli_close($con);
}
?>