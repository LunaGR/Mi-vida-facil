<?php 
require("conexion.php");
if (empty($_SESSION['usuario'])){
    header ('location:login.php');
 };

          /* formato de la petición de inserción mediante orden sql */
$sql="select IdUsuario from Usuario where NomUsuario='".$_SESSION['usuario']."';";

    $result = mysqli_query($con, $sql);

    $dir_subida = "./usuarios/".$_SESSION['usuario']."/albumes/";
    if (!is_dir($dir_subida)) {
        mkdir($dir_subida, 0777, true);
    }
    $idalbum = $_POST['album'];
    $tipo = $_FILES['fichero']['type'];
    if ($tipo != 'image/png' && $tipo != 'image/jpg' && $tipo != 'image/jpeg') {
        echo "<font color=red>Formato de imagen incorrecto</font>";
        exit;
    } 
    
    $query="select * from album where IdAlbum=$idalbum";
    $result= mysqli_query($con,$query);
    
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            $nombrealbum = $row['Titulo'];
        }
    }
    
    $fichero_subido = $dir_subida.basename($_FILES['fichero']['name']); 
    move_uploaded_file($_FILES['fichero']['tmp_name'], $fichero_subido);
    
    // Insertar los datos si el formato es correcto
        $sql="insert into foto values ('','".$_REQUEST['nombre']."','".$_REQUEST['fechacrea']."',".$_REQUEST['album'].",'".$fichero_subido."',current_time)";
    
        if (mysqli_query($con, $sql)) {
            echo "<font color=green>Foto añadida correctamente</font>";
        } else {
            echo "<font color=red>Error: " . $sql . "<br>" . mysqli_error($con) . "</font>";
        }
    
    mysqli_close($con);
    ?>